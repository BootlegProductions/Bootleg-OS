# Deploy the downloader in your existing Render account

1. Extract the ZIP and upload its contents (Dockerfile, server.mjs, package.json, render.yaml and the documentation) to the root of a new GitHub repository named `bootleg-youtube-backend`.
2. In Render, choose **New → Blueprint**, connect that GitHub repository, and review the configuration. The included blueprint selects the **Free** web-service plan and Docker. It creates a separate service; do not replace your Archive Scraper.
3. Deploy. The Dockerfile installs Node, Python, yt-dlp and ffmpeg; no manual build command is needed.
4. Copy the actual HTTPS service URL shown by Render. Visit `<that URL>/health` and wait for the first cold start; expect JSON with `ready: true`.
5. Send that URL back so the portfolio's `dist/js/download-config.js` can be updated to point to it. Nothing is connected until this URL is configured.
6. Test both MP4 and MP3 using a short public video you own. Confirm the resulting files actually play. If YouTube blocks the server, send the exact error; a health check alone is not proof of successful extraction.

The blueprint's CORS origins allow the current portfolio and the bootlegproductions GitHub Pages origin. Add any future custom domain to `ALLOWED_ORIGINS` in Render. Origins have no path or trailing slash.

Free hosting can take about a minute to wake and has ephemeral storage. The downloader intentionally expires temporary files after 30 minutes; restarts invalidate old jobs. It uses ffmpeg to merge MP4 streams and convert MP3 audio. YouTube can block cloud-provider IPs, so this is a deployable implementation, not a guarantee that every link can be extracted. Don't commit browser cookies or credentials to GitHub.

Routes: GET /health, POST /jobs with {url, format: "mp4" or "mp3", quality: "720" or "1080"}, GET /jobs/:id for progress, GET /jobs/:id/file to download, DELETE /jobs/:id to cancel.
