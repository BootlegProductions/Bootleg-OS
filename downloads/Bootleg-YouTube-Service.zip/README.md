# Bootleg YouTube service

The portfolio is static. This separate Docker service performs real yt-dlp downloads and ffmpeg conversion; GitHub Pages cannot run it.

Deploy `youtube-service/Dockerfile` with Docker build context `youtube-service` on Render (one instance). Set `ALLOWED_ORIGINS` to your exact portfolio origin, with additional origins comma-separated. No API secrets belong in frontend JavaScript. HTTPS is required. Set `window.BOOTLEG_DOWNLOAD_API` in `dist/js/download-config.js` to the deployed service's HTTPS origin, then redeploy the portfolio.

Test `/health`, then submit a short video you own in both MP4 and MP3, download it and play both files. Test from a phone too. Hosting is incomplete until those checks pass. YouTube sometimes blocks datacentre IPs: the service reports failures, and cannot guarantee access to every public video. Protected, private and live videos are not supported. No account cookies or blocking circumvention are implemented.

Limits: two concurrent jobs, 30-minute videos, 250 MB output, five requests per socket IP per minute, 30-minute temporary file retention. Reverse proxies can aggregate socket IPs; adjust production rate limiting at the proxy before increasing capacity. Job URLs carry random download tokens; don't share them unless you intend to share the file. This first deployment is for low traffic. Add persistent queue storage and stronger edge rate limiting before scaling to several instances. Ephemeral storage is intentional; a restart discards unfinished jobs. Monitor outbound traffic and hosting costs before public launch.

Local development: install Node 22, Python, `yt-dlp[default]`, ffmpeg; `ALLOWED_ORIGINS=http://localhost:8080 npm start`. No browser endpoints default to localhost. Tests: `npm test`.
