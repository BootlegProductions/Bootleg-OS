chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message.action !== 'open-sequencer') return;
  (async () => {
    const url = new URL(sender.url);
    if (sender.id !== chrome.runtime.id ||
        !Number.isInteger(sender.tab?.id) ||
        !['yarn.co','www.yarn.co','getyarn.io','www.getyarn.io','memes.yarn.co','memes.getyarn.io'].includes(url.hostname) ||
        url.protocol !== 'https:') throw Error('Open a Yarn clip page to launch Bootleg.');
    const hash = new URLSearchParams(url.hash.slice(1));
    const options = new URLSearchParams({tab:String(sender.tab.id)});
    for (const key of ['before','after']) {
      const value = hash.get('bootleg-' + key);
      if (value !== null && /^\d+$/.test(value) && Number(value) <= 15) options.set(key, value);
    }
    await chrome.windows.create({
      url: chrome.runtime.getURL('popup.html') + '?' + options,
      type: 'popup', width: 460, height: 680
    });
  })().then(() => respond({ok:true})).catch(error => respond({error:error.message}));
  return true;
});
