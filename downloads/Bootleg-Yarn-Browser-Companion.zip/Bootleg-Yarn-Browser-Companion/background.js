import {clipId,parseClip,filename,boundedCount} from './yarn-core.js';
let stopped=false,busy=false;
const state=async patch=>{const old=(await chrome.storage.local.get('job')).job||{};await chrome.storage.local.set({job:{...old,...patch}});};
async function readPage(tabId,id,first=false) {
  const [result]=await chrome.scripting.executeScript({target:{tabId},func:async (id,first)=>{
    try {
    const here=new URL(location.href),expected=`/yarn-clip/${id}`;
    if(!['getyarn.io','www.getyarn.io'].includes(here.hostname))throw Error('Keep the Yarn clip tab open.');
    if(first&&here.pathname.replace(/\/$/,'')===expected)return {html:document.documentElement.outerHTML};
    const r=await fetch(`${location.origin}${expected}`,{credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(30000)});
    if(r.status===403||r.status===429)throw Error(`Yarn refused this page (${r.status}). Collection stopped; no block will be bypassed.`);
    if(!r.ok)throw Error(`Clip page unavailable (${r.status}).`);
    return {html:await r.text()};
    } catch(error) { return {error:error.message || String(error)}; }
  },args:[id,first]});
  if(result?.result?.error)throw Error(result.result.error);
  if(!result?.result?.html)throw Error('Could not read Yarn. Open a clip page normally, then try the companion.');
  return parseClip(result.result.html,id);
}
async function collect(tabId,before,after) {
  if(busy)throw Error('A batch is already running.');busy=true;stopped=false;
  try {
    const tab=await chrome.tabs.get(tabId),start=clipId(tab.url);before=boundedCount(before);after=boundedCount(after);
    await state({status:'Reading the open starting clip…',clips:[],start,busy:true,folder:null});
    const center=await readPage(tabId,start,true),clips=[center],seen=new Set([start]);
    if(stopped)throw Error("Collection cancelled.");
    await state({clips});
    for(const [key,count] of [['previous',before],['next',after]]) {
      let cursor=center;
      for(let n=0;n<count;n++) {
        if(stopped)throw Error('Collection cancelled.');
        const id=cursor[key];if(!id||seen.has(id))break;seen.add(id);
        await state({status:`Reading ${key} clip ${n+1} of ${count}…`});
        await new Promise(r=>setTimeout(r,600));
        cursor=await readPage(tabId,id);if(stopped)throw Error('Collection cancelled.');key==='previous'?clips.unshift(cursor):clips.push(cursor);
        await state({clips});
      }
    }
    if(stopped)throw Error('Collection cancelled.');
    await state({clips,status:`Ready: ${clips.length} clips in scene order. Review, then download.`,busy:false});
  } catch(e) {await state({status:e.message||String(e),busy:false});}
  finally {busy=false;}
}
// One download at a time. onChanged drives the queue even after the popup closes.
async function downloadNext() {
  const {job}=await chrome.storage.local.get('job');if(!job?.downloading||job.activeDownload!=null)return;
  if(job.downloadIndex>=job.clips.length){await state({downloading:false,status:`Done: ${job.clips.length} MP4s saved in Downloads/${job.folder}.`});return;}
  const clip=job.clips[job.downloadIndex];
  try {const id=await chrome.downloads.download({url:clip.video,filename:`${job.folder}/${filename(job.downloadIndex,clip,job.start)}`,conflictAction:'uniquify',saveAs:false});
    const current=(await chrome.storage.local.get('job')).job;
    if(!current?.downloading||current.folder!==job.folder){await chrome.downloads.cancel(id);return;}
    await state({activeDownload:id,status:`Downloading ${job.downloadIndex+1} of ${job.clips.length}…`});
    // A short MP4 can finish before its ID reaches storage. Reconcile that race.
    const [download]=await chrome.downloads.search({id});
    if(download?.state!=='in_progress')settleDownload(id,download?.state);
  }
  catch(e){await state({downloading:false,status:`Download stopped: ${e.message}. Completed files are kept.`});}
}
let completionQueue=Promise.resolve();
function settleDownload(id,current) {
  completionQueue=completionQueue.then(async()=>{
    const {job}=await chrome.storage.local.get('job');
    if(id!==job?.activeDownload||!job.downloading)return;
    if(current==='complete'){await state({activeDownload:null,downloadIndex:job.downloadIndex+1});await downloadNext();}
    else if(current==='interrupted')await state({activeDownload:null,downloading:false,status:'Download interrupted. Completed clips are kept. You can retry the batch.'});
  }).catch(async error=>state({downloading:false,status:'Download queue stopped: '+error.message}));
}
chrome.downloads.onChanged.addListener(change=>{if(change.state)settleDownload(change.id,change.state.current);});
chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
  (async()=>{
    if(msg.action==='collect'){if(busy)throw Error('Collection is already running.');collect(msg.tabId,msg.before,msg.after);return;}
    if(msg.action==='stop'){stopped=true;const {job}=await chrome.storage.local.get('job');if(job?.activeDownload!=null)await chrome.downloads.cancel(job.activeDownload);await state({downloading:false,busy:false,status:'Stopped. Completed MP4s are kept.'});return;}
    if(msg.action==='download'){
      const {job}=await chrome.storage.local.get('job');if(!job?.clips?.length||job.busy)throw Error('Collect and review a sequence first.');if(job.downloading)return;
      const folder=`Bootleg-Yarn/${new Date().toISOString().replace(/[:.]/g,'-')}_${job.start.slice(0,8)}`;
      await state({folder,downloading:true,downloadIndex:0,activeDownload:null});await downloadNext();
    }
  })().then(()=>respond({ok:true})).catch(e=>respond({error:e.message}));return true;
});
