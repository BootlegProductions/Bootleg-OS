BOOTLEG YARN SEQUENCE DOWNLOADER — browser companion v2

1. Extract this ZIP to a folder you will keep.
2. Chrome: open chrome://extensions. Edge: open edge://extensions.
3. Enable Developer mode. Click Load unpacked and choose the folder containing manifest.json.
4. Open a Yarn clip normally in your browser, and wait for its page to load.
5. Click this extension in the browser toolbar. Choose 0–15 clips before and after.
6. Collect sequence, review the titles, then click Download MP4s.

Each batch goes into Downloads/Bootleg-Yarn in numbered scene order.
The original linked clip has START in its filename. The popup can close during downloads.
Keep the Yarn tab open during collection. Click Stop to cancel; completed MP4s remain.
Your browser may ask for download permission or a save location.

The companion reads only the Yarn tab you explicitly activate. It has no access to
all your browsing history and no external analytics, proxy, server or account.
Clip metadata is held locally in extension storage; downloads use Yarn's own media URLs.
It uses your normal browser session instead of a separate PowerShell HTTP client.
It does not bypass challenges or access restrictions: a 403/429 stops collection.
Use only clips you are entitled to save and reuse; downloading does not confer rights.

If Chrome reports that collection was interrupted, keep the page open and collect again.
A browser restart/service-worker termination during collection may require starting again.
Chrome/Edge desktop are supported. iPhone does not support this unpacked extension.
