Bootleg Yarn.co Sequencer 2.1

Update the existing unpacked extension by replacing its files with this folder, then click Reload on its chrome://extensions or edge://extensions card. Accept the Yarn site permissions if requested, then reload the Yarn clip page.

Click Choose clips on a Yarn clip page. Set before and after counts, Collect sequence, then Download ZIP. Keep both the Yarn page and sequencer window open until the ZIP is prepared. One ZIP contains all numbered MP4s. Yarn errors stop collection.
