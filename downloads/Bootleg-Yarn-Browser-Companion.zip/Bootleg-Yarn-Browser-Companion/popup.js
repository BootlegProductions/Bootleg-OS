import {clipId, boundedCount, parseClip, filename} from './yarn-core.js';
import {sequenceZip} from './zip.js';
import {readMP4} from './media.js';

const $ = id => document.getElementById(id);
const launch = new URLSearchParams(location.search);
const sourceId = Number(launch.get('tab'));
let sourceTab = null;
let sequence = null;
let controller = null;

function status(message) { $('status').textContent = message; }
function busy(value) {
  $('collect').disabled = value || !sourceTab;
  $('download').disabled = value || !sequence;
  $('before').disabled = value;
  $('after').disabled = value;
  $('stop').disabled = !value;
}
function cancel() { controller?.abort(); }

async function readClip(id, first, signal) {
  signal.throwIfAborted();
  const results = await chrome.scripting.executeScript({
    target: {tabId:sourceTab.id},
    func: async (id, first) => {
      try {
        const path = '/yarn-clip/' + id;
        const here = new URL(location.href);
        if (!['yarn.co','www.yarn.co','getyarn.io','www.getyarn.io','memes.yarn.co','memes.getyarn.io'].includes(here.hostname) ||
            here.protocol !== 'https:') throw Error('Keep your Yarn clip page open.');
        if (first) {
          const current = here.pathname.match(/^\/yarn-clip\/(?:embed\/)?([0-9a-f-]{36})(?:\/(?:gif|meme|embed))?\/?$/i);
          if (current?.[1].toLowerCase() !== id) throw Error('The starting clip changed. Reopen Choose clips on the clip you want.');
          return {html:document.documentElement.outerHTML};
        }
        const response = await fetch(here.origin + path, {
          credentials:'same-origin', redirect:'error', signal:AbortSignal.timeout(30000)
        });
        if (!response.ok) throw Error('Yarn refused a clip page (HTTP ' + response.status + ').');
        return {html:await response.text()};
      } catch (error) { return {error:error.message}; }
    },
    args: [id, first]
  });
  signal.throwIfAborted();
  const result = results[0]?.result;
  if (result?.error) throw Error(result.error);
  if (!result?.html) throw Error('Could not read the Yarn clip page.');
  return parseClip(result.html, id);
}

$('collect').onclick = async () => {
  if (controller) return;
  controller = new AbortController();
  const signal = controller.signal;
  sequence = null;
  $('clips').replaceChildren();
  busy(true);
  try {
    const counts = {before:boundedCount($('before').value), after:boundedCount($('after').value)};
    await chrome.storage.local.set({counts});
    status('Reading the clip already open on Yarn…');
    const start = clipId(sourceTab.url);
    const center = await readClip(start, true, signal);
    const clips = [center], seen = new Set([start]);
    for (const [direction, count] of [['previous',counts.before],['next',counts.after]]) {
      let current = center;
      for (let index = 0; index < count; index++) {
        const next = current[direction];
        if (!next || seen.has(next)) break;
        seen.add(next);
        status('Collecting ' + direction + ' clip ' + (index+1) + ' of ' + count + '…');
        await new Promise(resolve => setTimeout(resolve, 400));
        current = await readClip(next, false, signal);
        if (direction === 'previous') clips.unshift(current);
        else clips.push(current);
      }
    }
    signal.throwIfAborted();
    sequence = {start, clips};
    for (const clip of clips) {
      const row = document.createElement('li');
      row.textContent = (clip.id === start ? '★ START · ' : '') + clip.title;
      $('clips').append(row);
    }
    status('Ready: ' + clips.length + ' clips. Click Download ZIP.');
  } catch (error) {
    status(signal.aborted ? 'Collection cancelled.' : error.message);
  } finally {
    controller = null;
    busy(false);
  }
};

async function readMedia(clip, remaining, signal) {
  const url = new URL(clip.video);
  if (url.protocol !== 'https:' || url.port || url.username || url.password ||
      !['y.yarn.co','y.getyarn.io'].includes(url.hostname) || !/\.mp4$/i.test(url.pathname)) throw Error('Invalid Yarn media link.');
  const response = await fetch(url.href, {
    redirect:'error', signal:AbortSignal.any([signal,AbortSignal.timeout(30000)])
  });
  return readMP4(response, remaining);
}

$('download').onclick = async () => {
  if (controller || !sequence) return;
  controller = new AbortController();
  const signal = controller.signal;
  busy(true);
  try {
    const entries = [];
    let remaining = 64 * 1024 * 1024;
    for (const [index,clip] of sequence.clips.entries()) {
      status('Preparing clip ' + (index+1) + ' of ' + sequence.clips.length + '… Keep this window open.');
      let data;
      try { data = await readMedia(clip, remaining, signal); }
      catch (error) { throw Error('Clip ' + (index+1) + ': ' + error.message); }
      remaining -= data.length;
      entries.push({name:filename(index,clip,sequence.start),data});
    }
    signal.throwIfAborted();
    const url = URL.createObjectURL(sequenceZip(entries));
    try {
      await chrome.downloads.download({
        url,filename:'Bootleg-Yarn-sequence.zip',saveAs:false,conflictAction:'uniquify'
      });
      status('One ZIP sent to your browser downloads.');
    } finally { setTimeout(() => URL.revokeObjectURL(url),60000); }
  } catch (error) { status(signal.aborted ? 'ZIP cancelled.' : error.message); }
  finally { controller = null; busy(false); }
};

$('stop').onclick = cancel;
for (const id of ['before','after']) {
  $(id).addEventListener('input', () => {
    sequence = null;
    $('clips').replaceChildren();
    busy(false);
    status('Counts changed. Click Collect this sequence.');
  });
}
window.addEventListener('pagehide', cancel);

try {
  sourceTab = Number.isInteger(sourceId) && sourceId > 0
    ? await chrome.tabs.get(sourceId)
    : (await chrome.tabs.query({active:true,currentWindow:true}))[0];
  clipId(sourceTab.url);
  $('detected-clip').textContent = 'Starting clip: ' + (sourceTab.title || sourceTab.url);
  const saved = (await chrome.storage.local.get('counts')).counts || {before:3,after:3};
  for (const key of ['before','after']) $(key).value = boundedCount(launch.get(key) ?? saved[key]);
  $('collect').textContent = 'Collect this sequence';
  status('Current clip detected. Choose your counts, then collect.');
} catch (error) {
  sourceTab = null;
  status('Open Choose clips from a Yarn clip page. ' + error.message);
}
busy(false);
