import {clipId, boundedCount, filename} from './yarn-core.js';
import {sequenceZip} from './zip.js';
const $ = id => document.getElementById(id);
const sourceTab = Number(new URLSearchParams(location.search).get('tab'));
let detectedTab = null;
let currentStart = null, makingZip = false, archiveController = null;
const config = (await chrome.storage.local.get('counts')).counts;
if (config) { $('before').value = config.before; $('after').value = config.after; }
async function tab() {
  if (detectedTab) return chrome.tabs.get(detectedTab.id);
  if (Number.isInteger(sourceTab) && sourceTab > 0) return chrome.tabs.get(sourceTab);
  return (await chrome.tabs.query({active:true,currentWindow:true}))[0];
}
async function render() {
  const {job} = await chrome.storage.local.get('job');
  try { currentStart = clipId((await tab()).url); } catch { currentStart = null; }
  const matches = job && job.start === currentStart;
  const detected = $('detected-clip');
  if (currentStart) {
    const source = await tab();
    detected.textContent = 'Starting clip: ' + (source.title || currentStart);
    $('collect').textContent = 'Collect this sequence';
  } else {
    detected.textContent = 'Open the helper from a Yarn clip page to detect its starting clip.';
  }
  $('collect').disabled = makingZip || !!job?.busy || !!job?.downloading;
  $('download').disabled = makingZip || !matches || job.busy || !job.complete || !job.clips?.length;
  if (makingZip) return;
  $('status').textContent = matches ? job.status : 'Choose your clip counts, then Collect sequence.';
  $('clips').replaceChildren();
  if (!matches) return;
  for (const clip of job.clips || []) {
    const li = document.createElement('li');
    li.textContent = (clip.id === job.start ? '★ START · ' : '') + clip.title;
    $('clips').append(li);
  }
}
$('collect').onclick = async () => {
  try {
    const source = await tab();
    const counts = {before:boundedCount($('before').value),after:boundedCount($('after').value)};
    await chrome.storage.local.set({counts});
    const response = await chrome.runtime.sendMessage({action:'collect',tabId:source.id,...counts});
    if (response?.error) throw Error(response.error);
    await render();
  } catch (error) { $('status').textContent = error.message; }
};
$('download').onclick = async () => {
  if (makingZip) return;
  const {job} = await chrome.storage.local.get('job');
  if (!job?.complete || job.start !== clipId((await tab()).url)) return;
  makingZip = true;
  archiveController = new AbortController();
  await render();
  try {
    const entries = [];
    let remaining = 64 * 1024 * 1024;
    for (const [index, clip] of job.clips.entries()) {
      $('status').textContent = `Preparing clip ${index+1} of ${job.clips.length}… Keep this window open.`;
      const url = new URL(clip.video);
      if (url.protocol !== 'https:' || url.port || url.username || url.password ||
          !['y.yarn.co','y.getyarn.io'].includes(url.hostname) || !/\.mp4$/i.test(url.pathname)) throw Error('Invalid Yarn media link.');
      const response = await fetch(url.href,{redirect:'error',signal:AbortSignal.any([archiveController.signal,AbortSignal.timeout(30000)])});
      if (!response.ok) throw Error(`Yarn refused clip ${index+1} (HTTP ${response.status}).`);
      if (!/^(video\/mp4|application\/octet-stream)\b/i.test(response.headers.get('content-type')||'')) throw Error('Yarn returned a page instead of an MP4.');
      const chunks = [];
      let length = 0;
      for await (const chunk of response.body) {
        length += chunk.length;
        if (length > remaining) throw Error('This sequence exceeds the 64 MB ZIP limit. Choose fewer clips.');
        chunks.push(chunk);
      }
      if (!length) throw Error('Yarn returned an empty clip.');
      const data = new Uint8Array(length);
      let offset = 0;
      for (const chunk of chunks) { data.set(chunk,offset); offset += chunk.length; }
      remaining -= length;
      entries.push({name:filename(index,clip,job.start),data});
    }
    const url = URL.createObjectURL(sequenceZip(entries));
    try {
      await chrome.downloads.download({url,filename:'Bootleg-Yarn-sequence.zip',saveAs:false,conflictAction:'uniquify'});
      $('status').textContent = 'One ZIP sent to your browser downloads.';
    } finally { setTimeout(()=>URL.revokeObjectURL(url),60000); }
  } catch (error) { $('status').textContent = archiveController.signal.aborted ? 'ZIP cancelled.' : error.message; }
  finally {
    makingZip = false;
    $('collect').disabled = false;
    $('download').disabled = false;
  }
};
$('stop').onclick = async () => {
  archiveController?.abort();
  await chrome.runtime.sendMessage({action:'stop'});
  if (!makingZip) await render();
};
try {
  detectedTab = await tab();
  clipId(detectedTab.url);
} catch {
  detectedTab = null;
}
chrome.storage.onChanged.addListener(render);
await render();
