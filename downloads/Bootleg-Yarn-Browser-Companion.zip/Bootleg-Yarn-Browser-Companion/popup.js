import {clipId,boundedCount} from './yarn-core.js';
const $=id=>document.getElementById(id);
const config=(await chrome.storage.local.get('counts')).counts;if(config){$('before').value=config.before;$('after').value=config.after;}
async function render(){const {job}=await chrome.storage.local.get('job');if(!job)return;$('status').textContent=job.status;$('collect').disabled=job.busy||job.downloading;$('download').disabled=job.busy||job.downloading||!job.clips?.length;$('clips').replaceChildren();for(const clip of job.clips||[]){const li=document.createElement('li'),a=document.createElement('a');a.href=`https://getyarn.io/yarn-clip/${clip.id}`;a.target='_blank';a.rel='noopener';a.textContent=(clip.id===job.start?'★ START · ':'')+clip.title;li.append(a);$('clips').append(li);}}
async function send(action,more={}){const r=await chrome.runtime.sendMessage({action,...more});if(r?.error)$('status').textContent=r.error;else render();}
$('collect').onclick=async()=>{const [tab]=await chrome.tabs.query({active:true,currentWindow:true});const counts={before:Number($('before').value),after:Number($('after').value)};await chrome.storage.local.set({counts});send('collect',{tabId:tab.id,...counts});};
$('download').onclick=()=>send('download');$('stop').onclick=()=>send('stop');chrome.storage.onChanged.addListener(render);render();

$('import').onchange=async()=>{try{const data=JSON.parse(await $('import').files[0].text());clipId(data.url);$('before').value=boundedCount(data.before);$('after').value=boundedCount(data.after);$('expected').textContent='Settings imported. Open this starting clip before collecting: '+data.url;await chrome.storage.local.set({counts:{before:data.before,after:data.after}});}catch(e){$('status').textContent='Invalid batch settings: '+e.message;}};
