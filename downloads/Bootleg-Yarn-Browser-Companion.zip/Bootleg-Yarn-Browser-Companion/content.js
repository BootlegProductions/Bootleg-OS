(() => {
  if (window.top !== window) return;
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;right:20px;bottom:24px;z-index:2147483647';
  const root = host.attachShadow({mode:'closed'});
  root.innerHTML = `<style>
    .box{background:#1b1d36;color:#fff;border:2px solid #79d7e5;border-radius:12px;padding:14px;font:15px system-ui;box-shadow:0 4px 24px #0008;max-width:280px}
    p{margin:0 0 10px}button{font:inherit;cursor:pointer;border:0;border-radius:6px;padding:8px 12px;background:#79d7e5;color:#15132d}
    .dismiss{margin-left:8px;background:transparent;color:#fff}
  </style><div class="box"><p>Download this sequence with Bootleg?</p><button class="open">Choose clips</button><button class="dismiss" aria-label="Dismiss">×</button></div>`;
  root.querySelector('.open').onclick = async () => {
    try {
      const result = await chrome.runtime.sendMessage({action:'open-sequencer'});
      if (result?.error) root.querySelector('p').textContent = result.error;
    } catch { root.querySelector('p').textContent = 'Reload this Yarn page to reconnect Bootleg.'; }
  };
  let dismissed = '';
  root.querySelector('.dismiss').onclick = () => {dismissed = location.href; host.hidden = true;};
  function update() {
    const valid = /^\/yarn-clip\/(?:embed\/)?[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}(?:\/(?:gif|meme|embed))?\/?$/i.test(location.pathname);
    host.hidden = !valid || dismissed === location.href;
    if (!host.isConnected) document.documentElement.append(host);
  }
  update();
  setInterval(update, 1000);
})();
