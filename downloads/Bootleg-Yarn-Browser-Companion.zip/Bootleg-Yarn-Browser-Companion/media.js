export function isMP4(data) {
  const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
  let offset = 0;
  while (offset + 8 <= data.length && offset < 65536) {
    const size = view.getUint32(offset);
    const type = String.fromCharCode(...data.subarray(offset + 4, offset + 8));
    if (type === 'ftyp' || type === 'styp') return size >= 16 && size <= data.length - offset;
    if (!['free','skip','wide'].includes(type) || size < 8 || size > data.length - offset) return false;
    offset += size;
  }
  return false;
}

export async function readMP4(response, remaining) {
  if (!response.ok) throw Error('Yarn refused the MP4 (HTTP ' + response.status + ').');
  if (!response.body) throw Error('Yarn returned an empty clip.');
  const declared = Number(response.headers.get('content-length'));
  if (declared > remaining) {
    await response.body.cancel();
    throw Error('This sequence exceeds the 64 MB ZIP limit. Choose fewer clips.');
  }
  const chunks = [];
  let length = 0;
  for await (const chunk of response.body) {
    length += chunk.length;
    if (length > remaining) throw Error('This sequence exceeds the 64 MB ZIP limit. Choose fewer clips.');
    chunks.push(chunk);
  }
  if (!length) throw Error('Yarn returned an empty clip.');
  const data = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { data.set(chunk, offset); offset += chunk.length; }
  if (!isMP4(data)) {
    const type = response.headers.get('content-type') || 'unspecified file type';
    throw Error('Yarn returned an invalid video (' + type + '). The response contains no MP4 file header.');
  }
  return data;
}
