const encoder = new TextEncoder();
function checksum(data) {
  let crc = 0xffffffff;
  for (const byte of data) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0);
  }
  return (crc ^ 0xffffffff) >>> 0;
}
export function sequenceZip(entries) {
  const files = [], directory = [];
  let offset = 0, directorySize = 0;
  for (const {name, data} of entries) {
    const path = encoder.encode(name), crc = checksum(data);
    const local = new Uint8Array(30), l = new DataView(local.buffer);
    l.setUint32(0, 0x04034b50, true); l.setUint16(4, 20, true);
    l.setUint16(12, 33, true); l.setUint32(14, crc, true);
    l.setUint32(18, data.length, true); l.setUint32(22, data.length, true);
    l.setUint16(26, path.length, true);
    const central = new Uint8Array(46), c = new DataView(central.buffer);
    c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true);
    c.setUint16(14, 33, true); c.setUint32(16, crc, true);
    c.setUint32(20, data.length, true); c.setUint32(24, data.length, true);
    c.setUint16(28, path.length, true); c.setUint32(42, offset, true);
    files.push(local, path, data); directory.push(central, path);
    offset += local.length + path.length + data.length;
    directorySize += central.length + path.length;
  }
  const end = new Uint8Array(22), e = new DataView(end.buffer);
  e.setUint32(0, 0x06054b50, true); e.setUint16(8, entries.length, true);
  e.setUint16(10, entries.length, true); e.setUint32(12, directorySize, true);
  e.setUint32(16, offset, true);
  return new Blob([...files, ...directory, end], {type: 'application/zip'});
}
